This directory contains include files for ant and Makefile builds that are
shared between the JFlex examples.
